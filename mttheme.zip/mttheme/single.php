<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package Mttheme
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

get_header();

/* Start of the loop. */
while ( have_posts() ) : the_post();

	/* Post main class */
	$class = 'mttheme-main-content-wrap single-post-main-section';

	/* Filter for change layout style for ex. ?sidebar=right_sidebar */

	$author_url = get_author_posts_url( get_the_author_meta( 'ID' ) );

	$tags = get_the_tag_list();
	/* Get post class and id */
	$mttheme_post_classes = '';
	ob_start();
		post_class( $class );
		$mttheme_post_classes .= ob_get_contents();
	ob_end_clean();

	echo '<section id="post-'.esc_attr( get_the_ID() ).'" '.$mttheme_post_classes.'>'; // PHPCS:Ignore WordPress.Security.EscapeOutput.OutputNotEscaped
?>
		<div class="mttheme-rich-snippet d-none">
			<span class="entry-title">
				<?php echo esc_html( get_the_title() ); ?>
			</span>
			<span class="author vcard">
				<a class="url fn n" href="<?php echo esc_url( $author_url ); ?>">
					<?php echo esc_html( get_the_author() ); ?>
				</a>
			</span>
			<span class="published">
				<?php echo esc_html( get_the_date() ); ?>
			</span>
			<time class="updated" datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>">
				<?php echo esc_html( get_the_modified_date() ); ?>
			</time>
		</div>
		<div class="container-fluid">
			<div class="row">
				<div class="entry-content">
					<div class="post-title">
						<?php the_title( '<h3>', '</h3>' ); ?>
					</div>
					<div class="post-content">
						<?php the_content(); ?>
						<?php the_posts_pagination(); ?>
					</div>
				</div>
			</div>
		</div>
<?php
	echo '</section>'; // @codingStandardsIgnoreLine
endwhile; // End of the loop.
get_footer();