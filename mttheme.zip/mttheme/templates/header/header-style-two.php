<?php
/**
 * The template for displaying the header style 1
 *
 * @package Mttheme
 */

/* Exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$mttheme_logo             = get_theme_mod( 'mttheme_logo', '' );
$mttheme_logo_light       = get_theme_mod( 'mttheme_logo_light', '' );
$mttheme_logo_ratina      = get_theme_mod( 'mttheme_logo_ratina', '' );
$mttheme_logo_light_ratina= get_theme_mod( 'mttheme_logo_light_ratina', '' );

$mttheme_header_navigation_title = get_theme_mod( 'mttheme_header_navigation_title', __( 'Navigation', 'mttheme' ) );
$mttheme_header_menu    = get_theme_mod( 'mttheme_header_menu', '' );
?>

<!-- Navbar -->
<div class="navbar">
    <div class="logo">
        <?php if( $mttheme_logo || $mttheme_logo_light ) { ?>
            <?php if( $mttheme_logo_ratina ) { ?>
                <?php if( $mttheme_logo ) { ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ) ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="logo-light">
                        <img class="logo" src="<?php echo esc_url( $mttheme_logo ) ?>" data-rjs="<?php echo esc_url( $mttheme_logo_ratina ) ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                    </a>
                <?php } ?>
            <?php } else { ?>
                <?php if( $mttheme_logo ) { ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ) ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="logo-light">
                        <img class="logo" src="<?php echo esc_url( $mttheme_logo ) ?>" data-no-retina="" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                    </a>
                <?php } ?>
            <?php } ?>
            <?php if( $mttheme_logo_light_ratina ) { ?>
                <?php if( $mttheme_logo_light ) { ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ) ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="logo-dark">
                        <img class="logo" src="<?php echo esc_url( $mttheme_logo_light ) ?>" data-rjs="<?php echo esc_url( $mttheme_logo_light_ratina ) ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                    </a>
                <?php } ?>
            <?php } else { ?>
                <?php if( $mttheme_logo_light ) { ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ) ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="logo-dark">
                        <img class="logo" src="<?php echo esc_url( $mttheme_logo_light ) ?>" data-no-retina="" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                    </a>
                <?php } ?>
            <?php } ?>
        <?php } else { ?>
            <span class="site-title">
                <a href="<?php echo esc_url( home_url( '/' ) ) ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                    <?php echo esc_html( get_bloginfo( 'name' ) ); ?>
                </a>
            </span>
        <?php } ?>
    </div>

    <div class="navbar-buttons">
      <button class="button" type="button" name="button">SIGN IN</button>
      <span><img class="open-menu" src="https://designmodo.com/demo/full-nav-menu/images/menu.svg" alt="menu-image"></span>
    </div>
</div>

<!-- Overlay Navigation Menu -->
<div class="overlay">
    <h2 class="nav-title"><?php echo esc_html( $mttheme_header_navigation_title ); ?></h2>
    <nav class="overlay-menu mCustomScrollbar">
    <?php   
        if ( $mttheme_header_menu ) {
            $mttheme_header_menu_select = array(
                'container'       => 'ul',
                'menu_class'      => 'nav navbar-nav alt-font mttheme-normal-menu navbar-left no-margin',
                'menu'            => $mttheme_header_menu,
                'echo'            => true,
                'items_wrap'      => '<ul id="%1$s" class="simple-dropdown %2$s" data-in="fadeIn" data-out="fadeOut">%3$s</ul>',
            );
            wp_nav_menu( $mttheme_header_menu_select );
        }
        elseif( has_nav_menu( 'primary-menu' ) ) {
            $mttheme_header_menu_default = array(
                'theme_location'  => 'primary-menu',
                'container'       => 'ul',
                'menu_class'      => 'nav navbar-nav alt-font mttheme-normal-menu navbar-left no-margin',
                'menu_id'         => '',
                'echo'            => true,
                'items_wrap'      => '<ul id="%1$s" class="simple-dropdown %2$s" data-in="fadeIn" data-out="fadeOut">%3$s</ul>',
            );
            wp_nav_menu( $mttheme_header_menu_default );
        } else {
            $mttheme_header_menu_default = array( 
                'container'       => 'ul',
                'menu_class'      => 'nav navbar-nav alt-font mttheme-normal-menu navbar-left no-margin',
                'menu_id'         => '',
                'echo'            => true,
                'items_wrap'      => '<ul id="%1$s" class="simple-dropdown %2$s" data-in="fadeIn" data-out="fadeOut">%3$s</ul>',
            );
            wp_nav_menu( $mttheme_header_menu_default );
        }
    ?>
    </nav>
    <div class="close-menu"><a href="#"><img  src="https://designmodo.com/demo/full-nav-menu/images/close.svg" alt="close-image"></a></div>
</div>