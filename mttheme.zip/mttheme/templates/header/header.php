<?php
/**
 * The template for displaying the header
 *
 * @package Mttheme
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

$header_type = get_theme_mod( 'mttheme_header_style', 'header_type_1' );
?>
<!-- header -->
<header id="masthead" class="site-header <?php echo esc_attr( $header_type ); ?>" itemscope="itemscope" itemtype="http://schema.org/WPHeader">

	<div class="main-header-wrapper">

		<?php
		switch ( $header_type ) {
			case 'header_type_2':
			get_template_part( 'templates/header/header-style', 'two' );
			break;
			case 'header_type_3':
			get_template_part( 'templates/header/header-style', 'three' );
			break;
			case 'header_type_4':
			get_template_part( 'templates/header/header-style', 'four' );
			break;
			case 'header_type_1':
			default:
			get_template_part( 'templates/header/header-style', 'one' );
			break;
		}
		?>
		

	</div>
</header>
<!-- End header -->
