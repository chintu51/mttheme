<?php
/**
 * The template for displaying the header style 1
 *
 * @package Mttheme
 */

/* Exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$mttheme_logo             = get_theme_mod( 'mttheme_logo', '' );
$mttheme_logo_light       = get_theme_mod( 'mttheme_logo_light', '' );
$mttheme_logo_ratina      = get_theme_mod( 'mttheme_logo_ratina', '' );
$mttheme_logo_light_ratina= get_theme_mod( 'mttheme_logo_light_ratina', '' );

$mttheme_header_menu    = get_theme_mod( 'mttheme_header_menu', '' );
?>