<?php
    
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

    /* Check if 404 page image set ot not */
    $mttheme_image                = mttheme_get_image_id_by_url( get_theme_mod( 'mttheme_page_not_found_image', '' ) );    
    $mttheme_image_url            = wp_get_attachment_image_src( $mttheme_image, 'full' );
    $mttheme_page_not_found_image = ( $mttheme_image_url[0] ) ? ' style="background-image:url('.esc_url( $mttheme_image_url[0] ).');"': '';
    $mttheme_image_bg_class       = ( $mttheme_image ) ? ' cover-background': '';

    /* Get 404 page main title */
    $mttheme_page_not_found_main_title  = get_theme_mod( 'mttheme_page_not_found_main_title', __( 'OOPS!', 'mttheme' ) );
    
    /* Get 404 page subtitle */
    $mttheme_page_not_found_title    = get_theme_mod( 'mttheme_page_not_found_title', __( 'It looks like nothing was found at this location.Maybe try a search?', 'mttheme' ) );
    
    /* Get button text */
    $mttheme_page_not_found_button_text = get_theme_mod( 'mttheme_page_not_found_button_text', __( 'BACK TO HOME PAGE', 'mttheme' ) );
    /* Get button url */
    $mttheme_page_not_found_button_url  = get_theme_mod( 'mttheme_page_not_found_button_url', home_url( '/' ) );
    
    /* Check if search placeholder text */
    $mttheme_search_placeholder_text    = get_theme_mod( 'mttheme_search_placeholder_text', __( 'Enter your keywords...', 'mttheme' ) );


    echo '<section id="home" class="no-padding top-space z-index-1 position-relative' . esc_attr( $mttheme_image_bg_class ) . '"' . $mttheme_page_not_found_image . '>'; // @codingStandardsIgnoreLine
?>
        <div class="container position-relative full-screen page-not-found">
            <div class="slider-typography text-center">
                <div class="slider-text-middle-main">
                    <div class="slider-text-middle">
                        <div class="center-col mttheme-404-content-bg">
                            <div class="mttheme-404-content-wrap">
                                <?php if( $mttheme_page_not_found_main_title ) { ?>
                                    <?php $mttheme_page_not_found_main_title = str_replace( '||', '<br />', $mttheme_page_not_found_main_title ); ?>
                                    <h2 class="mttheme-404-main-title">
                                        <?php echo esc_html( $mttheme_page_not_found_main_title ) ?>
                                    </h2>
                                <?php } ?>
                                <?php if( $mttheme_page_not_found_title ) { ?>
                                    <?php $mttheme_page_not_found_title = str_replace( '||', '<br />', $mttheme_page_not_found_title ); ?>
                                    <h6 class="mttheme-404-subtitle">
                                        <?php echo esc_html( $mttheme_page_not_found_title ) ?>
                                    </h6>
                                <?php } ?>
                                <form action="<?php echo esc_url( home_url( '/' ) ) ?>" method="get" class="search-form position-relative">
                                    <div class="input-group-404 input-group">
                                        <input type="text" id="search" class="search-input" placeholder="<?php echo esc_attr( $mttheme_search_placeholder_text ) ?>" value="<?php echo get_search_query() ?>" name="s">
                                        <div class="input-group-btn">
                                            <button type="submit" class="btn alt-font">
                                                <i class="ti-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <a href="<?php echo esc_url( $mttheme_page_not_found_button_url ) ?>" class="btn btn-black btn-medium alt-font">
                                    <?php echo esc_html( $mttheme_page_not_found_button_text ) ?>
                                </a>
                            </div>
                        </div>                          
                    </div>
                </div>
            </div>
        </div>
    </section>