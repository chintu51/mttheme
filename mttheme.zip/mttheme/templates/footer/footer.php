<?php
/**
 * The template for displaying the footer part
 *
 * @package Mttheme
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* Check footer enable/disable */
$mttheme_footer_middle_column_1_sidebar = get_theme_mod( 'mttheme_footer_middle_column_1', 'footer-middle-column-1' );
$mttheme_footer_middle_column_2_sidebar = get_theme_mod( 'mttheme_footer_middle_column_2', 'footer-middle-column-2' );
$mttheme_footer_middle_column_3_sidebar = get_theme_mod( 'mttheme_footer_middle_column_3', 'footer-middle-column-3' );
$mttheme_footer_middle_column_4_sidebar = get_theme_mod( 'mttheme_footer_middle_column_4', 'footer-middle-column-4' );

$mttheme_footer_middle_column_1         = mttheme_check_active_sidebar( $mttheme_footer_middle_column_1_sidebar );
$mttheme_footer_middle_column_2         = mttheme_check_active_sidebar( $mttheme_footer_middle_column_2_sidebar );
$mttheme_footer_middle_column_3         = mttheme_check_active_sidebar( $mttheme_footer_middle_column_3_sidebar );
$mttheme_footer_middle_column_4         = mttheme_check_active_sidebar( $mttheme_footer_middle_column_4_sidebar );

?>
    <footer id="colophon" class="footer-default-wrapper site-footer" itemscope="itemscope" itemtype="http://schema.org/WPFooter">
        <?php if( $mttheme_footer_middle_column_1 || $mttheme_footer_middle_column_2 || $mttheme_footer_middle_column_3 || $mttheme_footer_middle_column_4 ) { ?>
            <div class="mttheme-footer-middle footer-four-column">
                <div class="container">
                    <div class="row">
                        <?php if ( $mttheme_footer_middle_column_1 ) { ?>
                            <div class="footer-sidebar col-md-3 col-sm-3 col-xs-12">
                                <?php dynamic_sidebar( $mttheme_footer_middle_column_1_sidebar ); ?>
                            </div>
                        <?php } ?>
                        <?php if ( $mttheme_footer_middle_column_2 ) { ?>
                            <div class="footer-sidebar col-md-3 col-sm-3 col-xs-12">
                                <?php dynamic_sidebar( $mttheme_footer_middle_column_2_sidebar ); ?>
                            </div>
                        <?php } ?>
                        <?php if ( $mttheme_footer_middle_column_3 ) { ?>
                            <div class="footer-sidebar col-md-3 col-sm-3 col-xs-12">
                                <?php dynamic_sidebar( $mttheme_footer_middle_column_3_sidebar ); ?>
                            </div>
                        <?php } ?>
                        <?php if ( $mttheme_footer_middle_column_4 ) { ?>
                            <div class="footer-sidebar col-md-3 col-sm-3 col-xs-12">
                                <?php dynamic_sidebar( $mttheme_footer_middle_column_4_sidebar ); ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        <?php } ?>
        <div class="mttheme-footer-bottom">
            <div class="site-info">
                <?php $blog_info = get_bloginfo( 'name' ); ?>
                <?php if ( ! empty( $blog_info ) ) : ?>
                    <a class="site-name" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a> - 
                <?php endif; ?>
                <a href="<?php echo esc_url( '//www.manektech.com/' ); ?>" class="imprint">
                    <?php
                        /* translators: %s: Manektech. */
                        _e( 'Proudly powered by Manektech.', 'mttheme' );
                    ?>
                </a>
            </div><!-- .site-info -->
        </div>
    </footer>