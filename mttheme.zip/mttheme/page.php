<?php
/**
 * The template for displaying all pages
 *
 * @package Mttheme
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

get_header(); 

/* Start of the loop. */
while ( have_posts() ) : the_post();
    
    /* Page main class */
    $class = 'mttheme-main-content-wrap';
    $header_top_space = get_theme_mod( 'header_top_space', false );
    $class .= ( $header_top_space ) ? ' header-top-space' : '';
    
    $author_url = get_author_posts_url( get_the_author_meta( 'ID' ) );

	/* Get post class and id */
	$mttheme_page_classes = '';
	ob_start();
		post_class( $class );
		$mttheme_page_classes .= ob_get_contents();
	ob_end_clean();
	
	echo '<div id="post-' . esc_attr( get_the_ID() ) . '" ' . $mttheme_page_classes . '>'; // PHPCS:Ignore WordPress.Security.EscapeOutput.OutputNotEscaped
?>	
		<div class="mttheme-rich-snippet d-none">
			<span class="entry-title">
				<?php echo esc_html( get_the_title() ); ?>
			</span>
			<span class="author vcard">
				<a class="url fn n" href="<?php echo esc_url( $author_url ); ?>">
					<?php echo esc_html( get_the_author() ); ?>
				</a>
			</span>
			<span class="published">
				<?php echo esc_html( get_the_date() ); ?>
			</span>
			<time class="updated" datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>">
				<?php echo esc_html( get_the_modified_date() ); ?>
			</time>
		</div>
		<div class="entry-content">
			<?php
				/* Get page content area */
				the_content();
			?>
			<?php
				/* Displays page-links for paginated pages. */
				wp_link_pages( 
					array(
						'before'     => '<div class="page-links"><div class="inner-page-links"><span class="pagination-title">' . esc_html__( 'Pages:', 'mttheme' ).'</span>',
						'after'      => '</div></div>',
						'link_before'=> '<span class="page-number">',
						'link_after' => '</span>',
					)
				);
				/* If comments are open or we have at least one comment, load up the comment template. */
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
			?>
		</div>
<?php
	echo '</div>'; // @codingStandardsIgnoreLine
endwhile;  // End of the loop.
get_footer();