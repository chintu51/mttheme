<?php
/**
 * This file use for define custom function
 * Also include required files.
 *
 * @package Mttheme
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 *  Mttheme Theme namespace.
 */
define( 'MTTHEME_THEME_VERSION', '1.0.0' );
define( 'MTTHEME_ADDONS_VERSION', '1.0.0' );

/**
 *  Mttheme Theme Folders
 */
define( 'MTTHEME_THEME_DIR',                    get_template_directory());
define( 'MTTHEME_THEME_ASSETS',                 MTTHEME_THEME_DIR . '/assets' );
define( 'MTTHEME_THEME_JS',                     MTTHEME_THEME_ASSETS . '/js' );
define( 'MTTHEME_THEME_CSS',                    MTTHEME_THEME_ASSETS . '/css' );
define( 'MTTHEME_THEME_IMAGES',                 MTTHEME_THEME_ASSETS . '/images' );
define( 'MTTHEME_THEME_ADMIN_JS',               MTTHEME_THEME_JS . '/admin' );
define( 'MTTHEME_THEME_ADMIN_CSS',              MTTHEME_THEME_CSS . '/admin' );
define( 'MTTHEME_THEME_LIB',                    MTTHEME_THEME_DIR . '/lib' );
define( 'MTTHEME_THEME_CUSTOMIZER',             MTTHEME_THEME_LIB . '/customizer' );
define( 'MTTHEME_THEME_CUSTOMIZER_MAPS',        MTTHEME_THEME_CUSTOMIZER . '/customizer-maps' );
define( 'MTTHEME_THEME_CUSTOMIZER_CONTROLS',    MTTHEME_THEME_CUSTOMIZER . '/customizer-control' );
define( 'MTTHEME_THEME_TGM',                    MTTHEME_THEME_LIB . '/tgm' );

/**
 *  Mttheme Theme Folder URI
 */
define( 'MTTHEME_THEME_URI',                    get_template_directory_uri());
define( 'MTTHEME_THEME_ASSETS_URI',             MTTHEME_THEME_URI     . '/assets' );
define( 'MTTHEME_THEME_JS_URI',                 MTTHEME_THEME_ASSETS_URI . '/js' );
define( 'MTTHEME_THEME_CSS_URI',                MTTHEME_THEME_ASSETS_URI . '/css' );
define( 'MTTHEME_THEME_IMAGES_URI',             MTTHEME_THEME_ASSETS_URI . '/images' );
define( 'MTTHEME_THEME_ADMIN_JS_URI',           MTTHEME_THEME_JS_URI . '/admin' );
define( 'MTTHEME_THEME_ADMIN_CSS_URI',          MTTHEME_THEME_CSS_URI . '/admin' );
define( 'MTTHEME_THEME_LIB_URI',                MTTHEME_THEME_URI . '/lib' );
define( 'MTTHEME_THEME_CUSTOMIZER_URI',         MTTHEME_THEME_LIB_URI . '/customizer' );
define( 'MTTHEME_THEME_CUSTOMIZER_MAPS_URI',    MTTHEME_THEME_CUSTOMIZER_URI . '/customizer-maps' );
define( 'MTTHEME_THEME_TGM_URI',                MTTHEME_THEME_LIB_URI . '/tgm' );


if ( file_exists( MTTHEME_THEME_LIB . '/theme-require-files.php' ) ) {
	require_once( MTTHEME_THEME_LIB . '/theme-require-files.php' );
}

// Register and load the widget
if ( ! function_exists( 'mttheme_account_menu' ) ) :
    function mttheme_account_menu() {
        register_widget( 'mttheme_account_menu' );
    }
endif;
add_action( 'widgets_init', 'mttheme_account_menu' );
 
// Creating the widget
if( ! class_exists( 'mttheme_account_menu' ) ) {
	class mttheme_account_menu extends WP_Widget {
	    function __construct() {
			parent::__construct(
				// Base ID of your widget
				'mttheme_account_menu', 

				// Widget name will appear in UI
				__( 'Mttheme Account Menu', 'mttheme' ),

				// Widget description
				array( 'description' => __( 'Display the Account Menu.', 'mttheme' ), ) 
			);
		}
	 
		// Creating widget front-end
		public function widget( $args, $instance ) {

			$title = apply_filters( 'widget_title', $instance['title'] );
			$nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

	 		echo $args['before_widget'];
	 			// For Login Logout Link
				if ( class_exists( 'woocommerce' ) ) {
					$myaccount_page_id 	= wc_get_page_id( 'myaccount' );
					$login_page_url 	= get_permalink( $myaccount_page_id );
					$logout_page_url 	= wc_logout_url( wc_get_page_permalink( 'myaccount' ) );
				} else{
					$login_page_url 	= wp_login_url();
					$logout_page_url 	= wp_logout_url();
				}
				
	 			if( $nav_menu && is_user_logged_in() ) {

	 				echo '<div class="mttheme-top-account-menu">';

	 					echo '<a class="account-menu-link" href="javascript:void(0);">';
	 						echo '<img src="' . MTTHEME_THEME_IMAGES_URI.'/user.png' . '">';
	 					echo '</a>';
 						if ( ! empty( $title ) ) {
	 						echo '<span>'. $title .'</span> <i class="ti-angle-down"></i>';
	 					}

						if( is_user_logged_in() ) {

							$login_logout_html = '<li><a class="account-menu-login" href="'. esc_url( $logout_page_url ) . '">'. __( 'Log out', 'mttheme' ) .'</a></li>';

			                $mttheme_header_menu_default = array(
	                            'menu'  			=> $nav_menu,
	                            'menu_class'    	=> 'mttheme-account-menu',
	                            'container'  		=> 'div',
	                            'container_class'	=> 'mttheme-account-menu-wrap',
	                            'items_wrap' 		=> '<ul id="%1$s" class="%2$s">%3$s'.$login_logout_html.'</ul>',
	                            'menu_class' 		=> 'alt-font',
	                            'fallback_cb'		=> false,
			                );
			                wp_nav_menu( $mttheme_header_menu_default );
						}

		        	echo '</div>';

	            } else {

 					if( is_user_logged_in() ) {

						$login_logout_html = $logout_page_url;

					} else {

						$login_logout_html = $login_page_url;
					}
	            	
	 				echo '<div class="mttheme-top-account-menu">';

		            	echo '<a class="account-menu-link" href="'. esc_url( $login_logout_html ) .'">';
		            		echo '<img src="' . MTTHEME_THEME_IMAGES_URI.'/user.png' . '">';
		            		if ( ! empty( $title ) ) {
	 							echo '<span>'. $title .'</span>';
	 						}
	 					echo '</a>';

		        	echo '</div>';
	            }

	 		echo $args['after_widget'];
  
	    } // Widget Backend

	    public function form( $instance ) {

	        $instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
	        $nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';
	        $menus1 = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
	        // Widget admin form
	    ?>
	        <p>
	            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'mttheme' ); ?></label>
	            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php if (isset ( $instance['title'])) {echo esc_attr( $instance['title'] );} ?>" />
	        </p>

	        <p>
		        <label for="<?php echo $this->get_field_id('nav_menu'); ?>"><?php _e( 'Select menu:', 'mttheme' ); ?></label>
		        <select id="<?php echo $this->get_field_id('nav_menu'); ?>" name="<?php echo $this->get_field_name('nav_menu'); ?>">
		            <option value=""><?php echo esc_html__( 'Select','mttheme' ); ?></option>
		            <?php
		            	if ( ! empty( $menus1 ) && ! is_wp_error( $menus1 ) ) {
		            		
		            		foreach ( $menus1 as $menu1 ) {
			                    echo '<option value="' . $menu1->slug . '"'. selected( $nav_menu, $menu1->slug, false ) . '>'. $menu1->name . '</option>';
			                }
		            	}
		            ?>
		        </select>
		    </p>
	        <?php
	    }

	    // Updating widget replacing old instances with new
	    public function update( $new_instance, $old_instance ) {
	        $instance = array();
	        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
	        $instance['nav_menu'] = isset( $new_instance['nav_menu'] ) ? $new_instance['nav_menu'] : '';
	        return $instance;
	    }

	} // Class mttheme_account_menu ends here
}