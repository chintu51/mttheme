<?php
/**
 * Theme Register Style Js.
 *
 * @package Mttheme
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

/*
 * Enqueue scripts and styles.
 */
if( ! function_exists( 'mttheme_register_style_js' ) ) :
	function mttheme_register_style_js() {

		/*
		 * Load Mttheme main and other required jquery files.
		 */
        wp_register_script( 'bootstrap', MTTHEME_THEME_JS_URI.'/bootstrap.min.js', array( 'jquery' ), '4.5.0', true);
		wp_enqueue_script( 'bootstrap' );
		
		wp_register_script( 'mttheme-custom', MTTHEME_THEME_JS_URI.'/custom.js', array( 'jquery' ), MTTHEME_THEME_VERSION, true );
		wp_enqueue_script( 'mttheme-custom' );

		/*
		 * Load Mttheme main and other required CSS files.
		 */
		wp_register_style( 'bootstrap', MTTHEME_THEME_CSS_URI . '/bootstrap.min.css', null, '4.5.0' );
		wp_enqueue_style( 'bootstrap' );
		
		wp_register_style( 'mttheme-google-font', 'https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap', null, MTTHEME_THEME_VERSION );
		
		wp_register_style( 'mttheme-style', get_stylesheet_uri(), null, MTTHEME_THEME_VERSION );
		wp_enqueue_style( 'mttheme-style' );

		// Load for wordpress comments
		if ( is_singular() && ( comments_open() || get_comments_number() ) && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
endif;
add_action( 'wp_enqueue_scripts', 'mttheme_register_style_js', -1 );

/* Enqueue Custom css base on customizer settings */
if( ! function_exists( 'mttheme_enqueue_custom_style' ) ) :
	function mttheme_enqueue_custom_style() {

		$output_css = '';
		ob_start();
		/* Include navigation css */
		require_once MTTHEME_THEME_CUSTOMIZER . '/customizer-output/custom-css.php';
		$output_css = ob_get_contents();
		ob_end_clean();

		// apply_filters for custom css so user can add its own custom css
		$output_css = apply_filters( 'mttheme_inline_custom_css', $output_css );

		// 1. Remove comments.
		// 2. Remove whitespace.
		// 3. Remove starting whitespace.
		$output_css = preg_replace( '#/\*.*?\*/#s', '', $output_css );
		$output_css = preg_replace( '/\s*([{}|:;,])\s+/', '$1', $output_css );
		$output_css = preg_replace( '/\s\s+(.*)/', '$1', $output_css );

		// apply_filters for custom css after minified so user can add its own custom css
		$output_css = apply_filters( 'mttheme_inline_custom_css_after_minified', $output_css );

		wp_add_inline_style( 'mttheme-style', $output_css );
	}
endif;
add_action( 'wp_enqueue_scripts', 'mttheme_enqueue_custom_style', 999 );

/*
 * Load mttheme customizer script.
 */
if( ! function_exists( 'mttheme_customizer_scripts_preview' ) ) :
	function mttheme_customizer_scripts_preview() {

	   	wp_enqueue_script( 'mttheme-customizer', MTTHEME_THEME_ADMIN_JS_URI.'/theme-customizer.js', array( 'jquery','customize-preview' ) );
	}
endif;
add_action( 'customize_preview_init','mttheme_customizer_scripts_preview' );

/*
 * Load theme admin css and script.
 */
if( ! function_exists( 'mttheme_admin_custom_scripts' ) ) :
	function mttheme_admin_custom_scripts() {
		
		// load media script
		wp_enqueue_media();

		wp_register_style( 'mttheme-admin-custom', MTTHEME_THEME_ADMIN_CSS_URI . '/theme-admin-custom.css', null, MTTHEME_THEME_VERSION );
		wp_enqueue_style( 'mttheme-admin-custom' );

	}
endif;
add_action( 'admin_enqueue_scripts', 'mttheme_admin_custom_scripts' );
