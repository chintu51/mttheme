<?php
/**
 * Register Mttheme theme required widget area.
 *
 * @package Mttheme
 */


// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'mttheme_widgets_init' ) ) {
    function mttheme_widgets_init() {

        register_sidebar( array(
            'name'          => __( 'Main Sidebar', 'mttheme' ),
            'id'            => 'sidebar-1',
            'description'   => __( 'Place widgets to show in your sidebar', 'mttheme' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font text-uppercase"><span>',
            'after_title'   => '</span></div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Mini Header Left Sidebar', 'mttheme' ),
            'id'            => 'mini-header-left-sidebar',
            'description'   => __( 'Place widgets to show in your mini header left side', 'mttheme' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Mini Header Center Sidebar', 'mttheme' ),
            'id'            => 'mini-header-center-sidebar',
            'description'   => __( 'Place widgets to show in your mini header center side', 'mttheme' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Mini Header Right Sidebar', 'mttheme' ),
            'id'            => 'mini-header-right-sidebar',
            'description'   => __( 'Place widgets to show in your mini header right side', 'mttheme' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Header Sidebar', 'mttheme' ),
            'id'            => 'header-sidebar',
            'description'   => __( 'Place widgets to show in your header right side', 'mttheme' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Top 1', 'mttheme' ),
            'id'            => 'footer-top-left',
            'description'   => __( 'Place widgets to show in your footer top 1 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Top 2', 'mttheme' ),
            'id'            => 'footer-top-center',
            'description'   => __( 'Place widgets to show in your footer top 2 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Top 3', 'mttheme' ),
            'id'            => 'footer-top-right',
            'description'   => __( 'Place widgets to show in your footer top 3 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Middle 1', 'mttheme' ),
            'id'            => 'footer-middle-column-1',
            'description'   => __( 'Place widgets to show in your footer middle column 1 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Middle 2', 'mttheme' ),
            'id'            => 'footer-middle-column-2',
            'description'   => __( 'Place widgets to show in your footer middle column 2 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Middle 3', 'mttheme' ),
            'id'            => 'footer-middle-column-3',
            'description'   => __( 'Place widgets to show in your footer middle column 3 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Middle 4', 'mttheme' ),
            'id'            => 'footer-middle-column-4',
            'description'   => __( 'Place widgets to show in your footer middle column 4 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Bottom 1', 'mttheme' ),
            'id'            => 'footer-bottom-left',
            'description'   => __( 'Place widgets to show in your footer bottom 1 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );

        register_sidebar( array(
            'name'          => __( 'Footer Bottom 2', 'mttheme' ),
            'id'            => 'footer-bottom-center',
            'description'   => __( 'Place widgets to show in your footer bottom 2 sidebar', 'mttheme' ),
            'before_widget' => '<div class="widget %2$s" id="%1$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title alt-font">',
            'after_title'   => '</div>',
        ) );
    }
}
add_action( 'widgets_init', 'mttheme_widgets_init' );