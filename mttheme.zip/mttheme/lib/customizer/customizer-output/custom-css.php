<?php
/**
 * Generate css.
 *
 * @package Mttheme
 */
?>
<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

    $mttheme_404_main_title_color = get_theme_mod( 'mttheme_404_main_title_color', '' );

    /* Header settings */
    $mttheme_header_bg_color = get_theme_mod( 'mttheme_header_bg_color', '' );
    $mttheme_header_bg_gradient_color = get_theme_mod( 'mttheme_header_bg_gradient_color', '' );
?>

<?php if( $mttheme_404_main_title_color ) : ?>
/* 404 Main Title Color */
.mttheme-404-main-title { color: <?php echo sprintf( '%s', $mttheme_404_main_title_color ); ?>; }
<?php endif; ?>

<?php if( $mttheme_header_bg_color ) : ?>
/* Header bg color */
.header_type_1 .head_bar, .header_type_1 .head_menu .menu_logo, .header_type_2 .navbar { background-color: <?php echo sprintf( '%s', $mttheme_header_bg_color ); ?>; }
<?php endif; ?>

<?php if( $mttheme_header_bg_color && $mttheme_header_bg_gradient_color ) : ?>
/* Header bg with gradient color */
.header_type_1 .head_bar, .header_type_1 .head_menu .menu_logo { background: linear-gradient( -60deg, <?php echo sprintf( '%s', $mttheme_header_bg_color ); ?>, <?php echo sprintf( '%s', $mttheme_header_bg_gradient_color ); ?> ); }
<?php endif; ?>