<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

Kirki::add_panel( 'mttheme_add_general_panel', array(
    'priority'    => 125,
    'title'       => esc_html__( 'General Theme Options', 'mttheme' ),
) );

Kirki::add_panel( 'mttheme_header_settings_panel', array(
    'priority'    => 130,
    'title'       => esc_html__( 'Header Settings', 'mttheme' ),
) );

Kirki::add_panel( 'mttheme_footer_settings_panel', array(
    'priority'    => 135,
    'title'       => esc_html__( 'Footer Settings', 'mttheme' ),
) );