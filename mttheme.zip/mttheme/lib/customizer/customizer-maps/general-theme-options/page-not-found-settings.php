<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

Kirki::add_section( 'mttheme_add_404_page_panel', array(
	'title'          => __( '404 Page', 'mttheme' ),
	'panel'          => 'mttheme_add_general_panel',
) );

	Kirki::add_field( 'mttheme_404_settings', [
		'type'        => 'custom',
		'settings'    => 'mttheme_page_not_found_divider',
		'default'     => '<h3 class="divider-section">' .  __( '404 page', 'mttheme' ) . '</h3>',
		'section'     => 'mttheme_add_404_page_panel',
	] );

	Kirki::add_field( 'mttheme_404_settings', [
		'type'        => 'image',
		'settings'    => 'mttheme_page_not_found_image',
		'label'       => __( 'Background image ', 'mttheme' ),
		'section'     => 'mttheme_add_404_page_panel',
	] );

	Kirki::add_field( 'mttheme_404_settings', [
		'type'        => 'text',
		'settings'    => 'mttheme_page_not_found_main_title',
		'label'       => __( 'Main title', 'mttheme' ),
		'default' 	  => __( 'OOPS!', 'mttheme' ),
		'section'     => 'mttheme_add_404_page_panel',
	] );

	Kirki::add_field( 'mttheme_404_settings', [
		'type'        => 'text',
		'settings'    => 'mttheme_page_not_found_title',
		'label'       => __( 'Title', 'mttheme' ),
		'default' 	  => __( 'That page can’t be found.', 'mttheme' ),
		'section'     => 'mttheme_add_404_page_panel',
	] );

	Kirki::add_field( 'mttheme_404_settings', [
		'type'        => 'text',
		'settings'    => 'mttheme_page_not_found_button_text',
		'label'       => __( 'Button text', 'mttheme' ),
		'default' 	  => __( 'BACK TO HOME PAGE', 'mttheme' ),
		'section'     => 'mttheme_add_404_page_panel',
	] );

	Kirki::add_field( 'mttheme_404_settings', [
		'type'        => 'text',
		'settings'    => 'mttheme_search_placeholder_text',
		'label'       => __( 'Search placeholder text', 'mttheme' ),
		'default' 	  => __( 'Enter your keywords...', 'mttheme' ),
		'section'     => 'mttheme_add_404_page_panel',
	] );

	Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'color',
        'settings'    => 'mttheme_404_main_title_color',
        'transport'   => 'postMessage',
        'label'       => __( 'Main title color', 'mttheme' ),
        'section'     => 'mttheme_add_404_page_panel',  
        'choices'     => [
            'alpha' => true,
        ],
    ] );