<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }
	
Kirki::add_section( 'mttheme_footer_section', array(
    'title'          => __( 'General Footer Settings', 'mttheme' ),
    'panel'          => 'mttheme_footer_settings_panel',
) );
	
	Kirki::add_field( 'mttheme_footer_settings', [
        'type'        => 'custom',
        'settings'    => 'mttheme_footer_general_divider',
        'section'     => 'mttheme_footer_section',
        'default'     => '<h3 class="divider-section">' . __( 'Footer settings', 'mttheme' ) . '</h3>',
    ] );