<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

// header section
Kirki::add_section( 'mttheme_header_section', array(
    'title' => __( 'General Header Settings', 'mttheme' ),
    'panel' => 'mttheme_header_settings_panel',
) );
    
    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'custom',
        'settings'    => 'mttheme_header_divider',
        'section'     => 'mttheme_header_section',
        'default'     => '<h3 class="divider-section">' . __( 'Header settings', 'mttheme' ) . '</h3>',
    ] );

    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'radio-image',
        'settings'    => 'mttheme_header_style',
        'label'       => __( 'Header Style', 'mttheme' ),
        'section'     => 'mttheme_header_section',
        'default'     => 'header_type_1',
        'choices'     => [
            'header_type_1'  => get_template_directory_uri() . '/assets/images/header/header_type_1.png',
            'header_type_2'  => get_template_directory_uri() . '/assets/images/header/header_type_2.png',
            'header_type_3'  => get_template_directory_uri() . '/assets/images/header/header_type_3.png',
        ],
    ] );

    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'select',
        'settings'    => 'mttheme_header_menu',
        'label'       => __( 'Header Main Menu', 'mttheme' ),
        'section'     => 'mttheme_header_section',
        'default'     => '',
        'placeholder' => esc_html__( 'Select header menu', 'mttheme' ),
        'multiple'    => 1,
        'choices'     => mttheme_get_nav_menus_array(),
    ] );
    
    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'radio-buttonset',
        'settings'    => 'mttheme_header_width',
        'label'       => __( 'Header Width', 'mttheme' ),
        'section'     => 'mttheme_header_section',
        'default'     => 'container-fluid',
        'choices'     => [
                            'container-fluid' => __( 'Full Width', 'mttheme' ),
                            'container'       => __( 'Boxed', 'mttheme' )
                        ],
    ] );

    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'select',
        'settings'    => 'mttheme_header',
        'label'       => __( 'Header Right Sidebar', 'mttheme' ),
        'section'     => 'mttheme_header_section',
        'default'     => 'header-sidebar',
        'placeholder' => esc_html__( 'Select header right sidebar', 'mttheme' ),
        'multiple'    => 1,
        'choices'     => mttheme_register_sidebar_customizer_array(),
    ] );
    
    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'switch',
        'settings'    => 'header_top_space',
        'label'       => __( 'Header Top Space', 'mttheme' ),
        'section'     => 'mttheme_header_section',
        'default'     => '0',
        'choices'     => [
                            '1'  => esc_html__( 'Yes', 'mttheme' ),
                            '0' => esc_html__( 'No', 'mttheme' ),
                        ],
    ] );
    
    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'custom',
        'settings'    => 'mttheme_header_color_divider',
        'section'     => 'mttheme_header_section',
        'default'     => '<h3 class="divider-section">' . __( 'Header Color Settings', 'mttheme' ) . '</h3>',
    ] );

    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'color',
        'settings'    => 'mttheme_header_bg_color',
        'label'       => __( 'Background', 'mttheme' ),
        'section'     => 'mttheme_header_section',  
        'choices'     => [
            'alpha' => true,
        ],
    ] );

    Kirki::add_field( 'mttheme_header_settings', [
        'type'        => 'color',
        'settings'    => 'mttheme_header_bg_gradient_color',
        'label'       => __( 'Background Gradient', 'mttheme' ),
        'section'     => 'mttheme_header_section',  
        'choices'     => [
            'alpha' => true,
        ],
        'active_callback' => [
            [
                'setting'  => 'mttheme_header_style',
                'operator' => '==',
                'value'    => 'header_type_1',
            ]
        ],
    ] );

    // Kirki::add_field( 'mttheme_header_settings', [
    //     'type'        => 'typography',
    //     'settings'    => 'mttheme_header_typography',
    //     'label'       => esc_html__( 'Header Typography', 'mttheme' ),
    //     'section'     => 'mttheme_header_section',
    //     'default'     => [
    //         'font-family'    => 'Roboto',
    //         'variant'        => 'regular',
    //         'font-size'      => '14px',
    //         'line-height'    => '1.5',
    //         'letter-spacing' => '0',
    //         'color'          => '#333333',
    //         'text-transform' => 'none',
    //         'text-align'     => 'left',
    //     ],
    //     'priority'    => 10,
    //     'transport'   => 'auto',
    //     'output'      => [
    //         [
    //             'element' => 'header .top_navbar .navbar-nav .nav-item .nav-link',
    //         ],
    //     ],
    // ] );