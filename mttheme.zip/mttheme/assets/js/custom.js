( function( $ ) {

    "use strict";

    var isMobile = false;
    var isiPhoneiPad = false;

    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        isMobile = true;
    }

    if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
        isiPhoneiPad = true;
    }
    
    /* Window ready event start code */
    $(document).ready(function () {
        
        // Header top space
        var HeaderHeight = $('header').outerHeight();

        $( '.mttheme-main-content-wrap.header-top-space' ).css( 'margin-top', HeaderHeight );

        // Header mobile menu
        $(document).on('click', '.navbar-toggler', function () {
            $(".icon01").toggleClass("icon_line");
            $(".icon02").toggleClass("line_hide");
            $(".icon03").toggleClass("icon_cross");        
            $("body").toggleClass("overflow-hidden");        
        });
        
    });
})( jQuery );